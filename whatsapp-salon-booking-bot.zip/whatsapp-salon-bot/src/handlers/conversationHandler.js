const { sendText, sendButtons, sendList } = require('../services/whatsappClient');
const { getAvailableSlots, bookSlot } = require('../services/calendarService');
const db = require('../services/db');
const { fillTemplate } = require('../config/clientStore');
const { randomUUID } = require('crypto');

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

/**
 * Entry point - called for every incoming WhatsApp message.
 * client = this salon's config (from clientStore)
 * from = customer's WhatsApp number
 * messageText = plain text the customer sent, OR the button/list id they tapped
 * customerName = WhatsApp profile name, if available
 */
async function handleIncomingMessage({ client, from, messageText, interactiveId, customerName }) {
  const state = db.getState(client.phoneNumberId, from);
  const input = interactiveId || messageText.trim();
  const lowerInput = input.toLowerCase();

  if (lowerInput === 'cancel') {
    db.clearState(client.phoneNumberId, from);
    await sendText(client.phoneNumberId, from, 'Your booking request has been cancelled. Message us anytime to start again.');
    return;
  }

  switch (state.step) {
    case 'start':
      return greet(client, from);

    case 'awaiting_menu_choice':
      return handleMenuChoice(client, from, input, state);

    case 'awaiting_service':
      return handleServiceChoice(client, from, input, state);

    case 'awaiting_day':
      return handleDayChoice(client, from, input, state);

    case 'awaiting_slot':
      return handleSlotChoice(client, from, input, state, customerName);

    default:
      db.clearState(client.phoneNumberId, from);
      return greet(client, from);
  }
}

async function greet(client, from) {
  const greeting = fillTemplate(client.messages.greeting, client);
  await sendButtons(client.phoneNumberId, from, greeting, [
    { id: 'menu_book', title: 'Book an appointment' },
    { id: 'menu_services', title: 'View services' },
    { id: 'menu_staff', title: 'Talk to staff' }
  ]);
  db.setState(client.phoneNumberId, from, { step: 'awaiting_menu_choice', data: {} });
}

async function handleMenuChoice(client, from, input, state) {
  if (input === 'menu_book') {
    return showServiceList(client, from);
  }
  if (input === 'menu_services') {
    const lines = client.services.map(s => `${s.name} - ₹${s.price} (${s.durationMinutes} min)`).join('\n');
    await sendText(client.phoneNumberId, from, `Our services:\n\n${lines}\n\nReply "book" anytime to book an appointment.`);
    db.setState(client.phoneNumberId, from, { step: 'awaiting_menu_choice', data: {} });
    return;
  }
  if (input === 'menu_staff') {
    await sendText(client.phoneNumberId, from, 'Sure, one moment - connecting you to our front desk. Someone will reply here shortly.');
    db.clearState(client.phoneNumberId, from);
    return;
  }
  return greet(client, from);
}

async function showServiceList(client, from) {
  const rows = client.services.map(s => ({
    id: `svc_${s.id}`,
    title: s.name,
    description: `₹${s.price} - ${s.durationMinutes} min`
  }));
  await sendList(client.phoneNumberId, from, 'Which service would you like to book?', 'Choose service', [
    { title: 'Services', rows }
  ]);
  db.setState(client.phoneNumberId, from, { step: 'awaiting_service', data: {} });
}

async function handleServiceChoice(client, from, input, state) {
  const serviceId = input.replace('svc_', '');
  const service = client.services.find(s => s.id === serviceId);
  if (!service) {
    return showServiceList(client, from);
  }

  await sendButtons(client.phoneNumberId, from, `${service.name} - ₹${service.price}, ${service.durationMinutes} min\n\nWhich day works for you?`, [
    { id: 'day_today', title: 'Today' },
    { id: 'day_tomorrow', title: 'Tomorrow' },
    { id: 'day_pick', title: 'Pick a date' }
  ]);

  db.setState(client.phoneNumberId, from, { step: 'awaiting_day', data: { serviceId: service.id } });
}

async function handleDayChoice(client, from, input, state) {
  let targetDate;
  const today = new Date();

  if (input === 'day_today') {
    targetDate = today;
  } else if (input === 'day_tomorrow') {
    targetDate = new Date(today);
    targetDate.setDate(today.getDate() + 1);
  } else if (input === 'day_pick') {
    await sendText(client.phoneNumberId, from, 'Please reply with the date you want, in DD-MM-YYYY format (e.g. 25-06-2026).');
    db.setState(client.phoneNumberId, from, { step: 'awaiting_day', data: state.data });
    return;
  } else if (/^\d{2}-\d{2}-\d{4}$/.test(input)) {
    const [d, m, y] = input.split('-');
    targetDate = new Date(`${y}-${m}-${d}`);
    if (isNaN(targetDate.getTime())) {
      await sendText(client.phoneNumberId, from, "I couldn't read that date. Please use DD-MM-YYYY format.");
      return;
    }
  } else {
    await sendText(client.phoneNumberId, from, 'Please choose Today, Tomorrow, or reply with a date in DD-MM-YYYY format.');
    return;
  }

  const dayName = DAY_NAMES[targetDate.getDay()];
  if (client.businessHours.closedDays.includes(dayName)) {
    await sendText(client.phoneNumberId, from, `We're closed on ${dayName}s. Please pick a different day.`);
    return;
  }

  const service = client.services.find(s => s.id === state.data.serviceId);
  const dateISO = targetDate.toISOString().split('T')[0];

  let slots;
  try {
    slots = await getAvailableSlots({
      calendarId: client.googleCalendarId,
      dateISO,
      openTime: client.businessHours.open,
      closeTime: client.businessHours.close,
      slotDurationMinutes: client.businessHours.slotDurationMinutes,
      serviceDurationMinutes: service.durationMinutes,
      timezone: client.timezone
    });
  } catch (err) {
    console.error('Calendar lookup failed:', err.message);
    await sendText(client.phoneNumberId, from, "Sorry, we're having trouble checking availability right now. Please try again in a moment, or reply 'staff' to talk to someone directly.");
    return;
  }

  if (slots.length === 0) {
    await sendText(client.phoneNumberId, from, 'No open slots that day, sorry! Please try another date.');
    db.setState(client.phoneNumberId, from, { step: 'awaiting_day', data: state.data });
    return;
  }

  const rows = slots.slice(0, 10).map(slot => ({
    id: `slot_${slot.toISOString()}`,
    title: slot.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true })
  }));

  await sendList(client.phoneNumberId, from, 'Here are open slots:', 'Choose time', [
    { title: dateISO, rows }
  ]);

  db.setState(client.phoneNumberId, from, {
    step: 'awaiting_slot',
    data: { ...state.data, dateISO }
  });
}

async function handleSlotChoice(client, from, input, state, customerName) {
  const isoString = input.replace('slot_', '');
  const startTime = new Date(isoString);

  if (isNaN(startTime.getTime())) {
    await sendText(client.phoneNumberId, from, "Sorry, I didn't catch that slot. Let's try again - reply 'book' to restart.");
    db.clearState(client.phoneNumberId, from);
    return;
  }

  const service = client.services.find(s => s.id === state.data.serviceId);

  let event;
  try {
    event = await bookSlot({
      calendarId: client.googleCalendarId,
      startTime,
      durationMinutes: service.durationMinutes,
      customerName,
      customerPhone: from,
      serviceName: service.name,
      timezone: client.timezone
    });
  } catch (err) {
    console.error('Booking failed:', err.message);
    await sendText(client.phoneNumberId, from, "Sorry, that slot couldn't be booked - it may have just been taken. Please reply 'book' to try another time.");
    db.clearState(client.phoneNumberId, from);
    return;
  }

  const bookingId = randomUUID();
  db.saveBooking({
    id: bookingId,
    phoneNumberId: client.phoneNumberId,
    customerPhone: from,
    customerName: customerName || null,
    serviceName: service.name,
    startTime: startTime.toISOString(),
    calendarEventId: event.id,
    reminderSent: false,
    reviewRequestSent: false
  });

  const timeLabel = startTime.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
  const dateLabel = startTime.toLocaleDateString('en-IN', { day: 'numeric', month: 'long' });

  await sendText(
    client.phoneNumberId,
    from,
    `You're booked! ✅\n\n${service.name} - ${timeLabel}, ${dateLabel}\n${client.businessName}, ${client.city}\n\nWe'll send a reminder before your appointment. Reply CANCEL anytime to cancel.`
  );

  db.clearState(client.phoneNumberId, from);
}

module.exports = { handleIncomingMessage };
