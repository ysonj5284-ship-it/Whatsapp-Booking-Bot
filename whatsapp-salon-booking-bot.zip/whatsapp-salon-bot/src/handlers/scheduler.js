const cron = require('node-cron');
const db = require('../services/db');
const { sendText } = require('../services/whatsappClient');
const { getClientByPhoneNumberId, fillTemplate } = require('../config/clientStore');

const ONE_HOUR_MS = 60 * 60 * 1000;

function startSchedulers() {
  // Every 5 minutes: check for bookings starting within the next hour, send reminder once
  cron.schedule('*/5 * * * *', async () => {
    const upcoming = db.getUpcomingBookings(ONE_HOUR_MS);
    for (const booking of upcoming) {
      const client = getClientByPhoneNumberId(booking.phoneNumberId);
      if (!client) continue;

      const timeLabel = new Date(booking.startTime).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
      await sendText(
        booking.phoneNumberId,
        booking.customerPhone,
        `Hi! Just a reminder - your ${booking.serviceName} appointment is coming up at ${timeLabel} today. See you soon!`
      );
      db.markReminderSent(booking.id);
    }
  });

  // Once a day at 11am: send review requests for yesterday's completed appointments
  cron.schedule('0 11 * * *', async () => {
    const yesterdaysBookings = db.getBookingsFromYesterday();
    for (const booking of yesterdaysBookings) {
      const client = getClientByPhoneNumberId(booking.phoneNumberId);
      if (!client) continue;

      const reviewText = fillTemplate(client.messages.reviewRequest, client);
      const linkText = client.messages.googleReviewLink
        ? `\n\n${client.messages.googleReviewLink}`
        : '';

      await sendText(booking.phoneNumberId, booking.customerPhone, reviewText + linkText);
      db.markReviewRequestSent(booking.id);
    }
  });

  console.log('Schedulers started: reminders every 5 min, review requests daily at 11am.');
}

module.exports = { startSchedulers };
