/**
 * Meta's webhook payload is deeply nested. This extracts the parts we need:
 * which salon (phone_number_id), which customer (from), and what they said.
 * Returns null if this isn't an actual incoming message (e.g. it's a status update).
 */
function parseIncomingMessage(body) {
  try {
    const entry = body.entry && body.entry[0];
    const change = entry && entry.changes && entry.changes[0];
    const value = change && change.value;

    if (!value || !value.messages || value.messages.length === 0) {
      return null;
    }

    const message = value.messages[0];
    const phoneNumberId = value.metadata.phone_number_id;
    const from = message.from;
    const customerName = (value.contacts && value.contacts[0] && value.contacts[0].profile && value.contacts[0].profile.name) || null;

    let messageText = '';
    let interactiveId = null;

    if (message.type === 'text') {
      messageText = message.text.body;
    } else if (message.type === 'interactive') {
      if (message.interactive.type === 'button_reply') {
        interactiveId = message.interactive.button_reply.id;
        messageText = message.interactive.button_reply.title;
      } else if (message.interactive.type === 'list_reply') {
        interactiveId = message.interactive.list_reply.id;
        messageText = message.interactive.list_reply.title;
      }
    } else {
      messageText = '';
    }

    return { phoneNumberId, from, messageText, interactiveId, customerName };
  } catch (err) {
    console.error('Failed to parse webhook payload:', err.message);
    return null;
  }
}

module.exports = { parseIncomingMessage };
