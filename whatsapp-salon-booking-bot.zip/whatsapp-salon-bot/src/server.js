require('dotenv').config();
const express = require('express');
const { parseIncomingMessage } = require('./handlers/webhookParser');
const { handleIncomingMessage } = require('./handlers/conversationHandler');
const { getClientByPhoneNumberId } = require('./config/clientStore');
const { startSchedulers } = require('./handlers/scheduler');

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// Health check - useful for confirming the server is alive after deploy
app.get('/', (req, res) => {
  res.send('WhatsApp salon booking bot is running.');
});

/**
 * Meta calls this with a GET request once, when you first set up the webhook
 * in Meta Business Suite, to verify you own this server.
 */
app.get('/webhook', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WEBHOOK_VERIFY_TOKEN) {
    console.log('Webhook verified successfully.');
    return res.status(200).send(challenge);
  }
  return res.sendStatus(403);
});

/**
 * Meta calls this every time a customer sends a message to any connected salon number.
 */
app.post('/webhook', async (req, res) => {
  // Always respond 200 immediately - Meta retries aggressively if you don't
  res.sendStatus(200);

  const parsed = parseIncomingMessage(req.body);
  if (!parsed) return; // not an actual message (could be a delivery/read status update)

  const { phoneNumberId, from, messageText, interactiveId, customerName } = parsed;

  const client = getClientByPhoneNumberId(phoneNumberId);
  if (!client) {
    console.error(`Received message for unknown phone_number_id: ${phoneNumberId}. Add it to clients.json.`);
    return;
  }

  try {
    await handleIncomingMessage({ client, from, messageText, interactiveId, customerName });
  } catch (err) {
    console.error('Error handling incoming message:', err);
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
  startSchedulers();
});
