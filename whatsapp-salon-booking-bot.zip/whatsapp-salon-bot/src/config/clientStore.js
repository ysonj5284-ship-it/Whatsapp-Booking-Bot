const fs = require('fs');
const path = require('path');

const CLIENTS_PATH = path.join(__dirname, 'clients.json');

function loadClients() {
  const raw = fs.readFileSync(CLIENTS_PATH, 'utf-8');
  const data = JSON.parse(raw);
  delete data._comment;
  return data;
}

function getClientByPhoneNumberId(phoneNumberId) {
  const clients = loadClients();
  const client = clients[phoneNumberId];
  if (!client) {
    console.error(`No client config found for phone_number_id: ${phoneNumberId}`);
    return null;
  }
  return { phoneNumberId, ...client };
}

function getAllClients() {
  const clients = loadClients();
  return Object.entries(clients).map(([phoneNumberId, cfg]) => ({ phoneNumberId, ...cfg }));
}

function fillTemplate(template, client) {
  return template.replace(/\{businessName\}/g, client.businessName);
}

module.exports = { getClientByPhoneNumberId, getAllClients, fillTemplate };
