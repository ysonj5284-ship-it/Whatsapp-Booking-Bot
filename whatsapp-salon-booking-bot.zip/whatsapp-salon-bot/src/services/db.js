const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');

const adapter = new FileSync(path.join(__dirname, '..', '..', 'data.json'));
const db = low(adapter);

db.defaults({ conversations: {}, bookings: [] }).write();

function conversationKey(phoneNumberId, customerNumber) {
  return `${phoneNumberId}__${customerNumber}`;
}

function getState(phoneNumberId, customerNumber) {
  const key = conversationKey(phoneNumberId, customerNumber);
  return db.get('conversations').get(key).value() || { step: 'start', data: {} };
}

function setState(phoneNumberId, customerNumber, state) {
  const key = conversationKey(phoneNumberId, customerNumber);
  db.get('conversations').set(key, state).write();
}

function clearState(phoneNumberId, customerNumber) {
  const key = conversationKey(phoneNumberId, customerNumber);
  db.get('conversations').unset(key).write();
}

function saveBooking(booking) {
  db.get('bookings').push({ ...booking, createdAt: new Date().toISOString() }).write();
}

function getUpcomingBookings(withinMs) {
  const now = Date.now();
  return db.get('bookings').value().filter(b => {
    const start = new Date(b.startTime).getTime();
    return start > now && start - now <= withinMs && !b.reminderSent;
  });
}

function markReminderSent(bookingId) {
  db.get('bookings')
    .find({ id: bookingId })
    .assign({ reminderSent: true })
    .write();
}

function getBookingsFromYesterday() {
  const now = new Date();
  const yesterdayStart = new Date(now);
  yesterdayStart.setDate(now.getDate() - 1);
  yesterdayStart.setHours(0, 0, 0, 0);
  const yesterdayEnd = new Date(yesterdayStart);
  yesterdayEnd.setHours(23, 59, 59, 999);

  return db.get('bookings').value().filter(b => {
    const start = new Date(b.startTime).getTime();
    return start >= yesterdayStart.getTime() && start <= yesterdayEnd.getTime() && !b.reviewRequestSent;
  });
}

function markReviewRequestSent(bookingId) {
  db.get('bookings')
    .find({ id: bookingId })
    .assign({ reviewRequestSent: true })
    .write();
}

module.exports = {
  getState,
  setState,
  clearState,
  saveBooking,
  getUpcomingBookings,
  markReminderSent,
  getBookingsFromYesterday,
  markReviewRequestSent
};
