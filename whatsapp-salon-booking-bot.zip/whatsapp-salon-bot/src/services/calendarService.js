const { google } = require('googleapis');
const path = require('path');

let calendarClient = null;

function getCalendarClient() {
  if (calendarClient) return calendarClient;

  const keyPath = process.env.GOOGLE_SERVICE_ACCOUNT_KEY_PATH || './google-service-account.json';
  const auth = new google.auth.GoogleAuth({
    keyFile: path.resolve(keyPath),
    scopes: ['https://www.googleapis.com/auth/calendar']
  });

  calendarClient = google.calendar({ version: 'v3', auth });
  return calendarClient;
}

/**
 * Returns available slot start times (as Date objects) for a given day,
 * based on business hours minus any existing calendar events.
 */
async function getAvailableSlots({ calendarId, dateISO, openTime, closeTime, slotDurationMinutes, serviceDurationMinutes, timezone }) {
  const calendar = getCalendarClient();

  const dayStart = new Date(`${dateISO}T${openTime}:00`);
  const dayEnd = new Date(`${dateISO}T${closeTime}:00`);

  const events = await calendar.events.list({
    calendarId,
    timeMin: dayStart.toISOString(),
    timeMax: dayEnd.toISOString(),
    singleEvents: true,
    orderBy: 'startTime',
    timeZone: timezone
  });

  const busy = (events.data.items || []).map(ev => ({
    start: new Date(ev.start.dateTime || ev.start.date),
    end: new Date(ev.end.dateTime || ev.end.date)
  }));

  const slots = [];
  const stepMs = slotDurationMinutes * 60 * 1000;
  const durationMs = serviceDurationMinutes * 60 * 1000;

  for (let t = dayStart.getTime(); t + durationMs <= dayEnd.getTime(); t += stepMs) {
    const slotStart = new Date(t);
    const slotEnd = new Date(t + durationMs);

    const overlaps = busy.some(b => slotStart < b.end && slotEnd > b.start);
    const isPast = slotStart < new Date();

    if (!overlaps && !isPast) {
      slots.push(slotStart);
    }
  }

  return slots;
}

/**
 * Books an appointment as a Google Calendar event.
 */
async function bookSlot({ calendarId, startTime, durationMinutes, customerName, customerPhone, serviceName, timezone }) {
  const calendar = getCalendarClient();
  const endTime = new Date(startTime.getTime() + durationMinutes * 60 * 1000);

  const event = await calendar.events.insert({
    calendarId,
    requestBody: {
      summary: `${serviceName} - ${customerName || customerPhone}`,
      description: `Booked via WhatsApp bot.\nCustomer: ${customerName || 'Not provided'}\nPhone: ${customerPhone}\nService: ${serviceName}`,
      start: { dateTime: startTime.toISOString(), timeZone: timezone },
      end: { dateTime: endTime.toISOString(), timeZone: timezone }
    }
  });

  return event.data;
}

module.exports = { getAvailableSlots, bookSlot };
