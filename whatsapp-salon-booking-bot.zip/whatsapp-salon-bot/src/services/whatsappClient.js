const axios = require('axios');

const GRAPH_API_VERSION = 'v20.0';
const GRAPH_BASE = `https://graph.facebook.com/${GRAPH_API_VERSION}`;

function client() {
  return axios.create({
    baseURL: GRAPH_BASE,
    headers: {
      Authorization: `Bearer ${process.env.WHATSAPP_TOKEN}`,
      'Content-Type': 'application/json'
    }
  });
}

/**
 * Sends a plain text message.
 * phoneNumberId = the SALON's phone_number_id (sender)
 * to = customer's WhatsApp number, digits only with country code, e.g. 919876543210
 */
async function sendText(phoneNumberId, to, body) {
  try {
    await client().post(`/${phoneNumberId}/messages`, {
      messaging_product: 'whatsapp',
      to,
      type: 'text',
      text: { body }
    });
  } catch (err) {
    logError('sendText', err);
  }
}

/**
 * Sends up to 3 tappable quick-reply buttons.
 * buttons = [{ id: 'svc_haircut', title: 'Haircut & styling' }, ...]
 */
async function sendButtons(phoneNumberId, to, bodyText, buttons) {
  if (buttons.length > 3) {
    throw new Error('WhatsApp interactive buttons support max 3 options - use sendList for more');
  }
  try {
    await client().post(`/${phoneNumberId}/messages`, {
      messaging_product: 'whatsapp',
      to,
      type: 'interactive',
      interactive: {
        type: 'button',
        body: { text: bodyText },
        action: {
          buttons: buttons.map(b => ({
            type: 'reply',
            reply: { id: b.id, title: b.title.substring(0, 20) }
          }))
        }
      }
    });
  } catch (err) {
    logError('sendButtons', err);
  }
}

/**
 * Sends a scrollable list - use this for 4+ options (e.g. services, time slots).
 * sections = [{ title: 'Available slots', rows: [{ id: 'slot_1100', title: '11:00 AM', description: '' }] }]
 */
async function sendList(phoneNumberId, to, bodyText, buttonLabel, sections) {
  try {
    await client().post(`/${phoneNumberId}/messages`, {
      messaging_product: 'whatsapp',
      to,
      type: 'interactive',
      interactive: {
        type: 'list',
        body: { text: bodyText },
        action: {
          button: buttonLabel.substring(0, 20),
          sections
        }
      }
    });
  } catch (err) {
    logError('sendList', err);
  }
}

function logError(fnName, err) {
  const detail = err.response ? JSON.stringify(err.response.data) : err.message;
  console.error(`[whatsappClient.${fnName}] failed:`, detail);
}

module.exports = { sendText, sendButtons, sendList };
